source global.cfg
source ../../config/spec.cfg

original_path=${PWD}


